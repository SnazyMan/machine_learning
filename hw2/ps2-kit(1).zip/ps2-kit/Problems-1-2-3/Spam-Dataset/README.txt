This folder contains a spam classification data set drawn from the UCI Machine Learning repository (http://archive.ics.uci.edu/ml/datasets/Spambase) and normalized to have each feature value in the range [0, 1]. In the data files provided, each row is a separate training example; the first 57 columns correspond to features, while the last column is the label (+1/-1).

Files:
train.txt - Training instances + labels (250 x 58)
test.txt - Test instances + labels (4351 x 58)

Folders:
CrossValidation - contains the train and test data for each fold of the 5-fold cross-validation procedure on the training set.
TrainSubsets - contains different sized subsets of the training set in train.txt (10%, 20%, ..., 100%).
