This folder contains a 2-dimensional synthetic data for binary classification. In the data files provided, each row is a separate training example; the first 2 columns are the features, while the last column has the labels (+1/-1). 

Files:
train.txt - Training instances + labels
test.txt - Test instances + labels 

Folder:
CrossValidation - contains the cross-validation data for each fold of the 5-fold cross-validation procedure on the training set.
